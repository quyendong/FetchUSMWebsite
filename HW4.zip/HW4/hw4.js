/* 
Quyen Dong
W899090
CSC440
ASSIGNMENT HW4:
Use fetch to make a asynchronous call to 
http://catalog.usm.edu/preview_program.php?catoid=17&poid=7796&returnto=973 (Links to an external site.)
Once you obtain the html code, 
Create a JavaScript object and insert the non-link words such as GEC01 as keys 
and the list of courses are values. 
Use an array for the courses.
For example, { ENG101 : [ 'Composition One', '3hrs'] }



HOW TO GET FETCH:
npm init //starts json package
npm install node-fetch --save
*/

const url = 'http://catalog.usm.edu/preview_program.php?catoid=17&poid=7796&returnto=973';
const fetch = require('node-fetch');
const bluebird = require('bluebird');

let myFetch = fetch(url);
myFetch.then(function(response){
	response.text().then(function(text)
	{
		//console.log(text) //outputs html code
	 	regex1 = /GEC\d+/g;
	 	let tempKeyArray = text.match(regex1);
	 //	console.log(tempKeyArray)
	 	tempKeyArray.pop();
	 	tempKeyArray.pop();
	 	let keyArray = Object.values(tempKeyArray); //set the values of keyArray to key
	 	let gec1 = /ENG\s10(1|2)/g;
	 	let tempvalue = text.match(gec1);
	 	tempvalue.pop();
	 	tempvalue.pop();
	 	tempvalue.pop();
	 	tempvalue.pop();
	 	let object = {};
	 	for (key in keyArray)
	 	{
	 		object[keyArray[key]] = keyArray[key];
	 	} 
	 //	console.log(tempvalue)
	 	object['GEC01'] = tempvalue;
	 	let gec2 = /AST\s11(1|2)\/?L?|BSC\s(1|2)(03|10|11|51|50)\/?L?|BSC\s25(0|1)\/?L?|CHE\s10(4|6|7)\/?L?|GHY\s10(4|5)\/?L?|GLY\s10(1|3)\/?L?|MAR\s15(0|1)\/?L?|PHY\s(1|2)(0|1)(1|2)\/?L?|PSC\s190\/?L?/g
	 	tempvalue = text.match(gec2);
	 	for (i=0; i<36; i++)
	 	{
	 		tempvalue.pop();
	 	}
	 	object['GEC02'] = tempvalue;
	 	let gec3 = /ENG\s203|HIS\s10(1|2)|PHI\s1(5|7)1|REL\s131/g
	 	tempvalue = text.match(gec3);
	 	object['GEC03'] = tempvalue;
	 	let gec4 = /ART\s130|DAN\s130|MUS\s165|THE\s100/g
	 	tempvalue = text.match(gec4);
	 	object['GEC04'] = tempvalue;
		let gec5 = /(ANT|COH|ECO|GHY|PS|PSY|SOC)\s1(0|1)(0|1)/g
		tempvalue = text.match(gec5);
		object['GEC05'] = tempvalue;
		let gec6 = /MAT\s10(0|1)/g;
		tempvalue = text.match(gec6);
		tempvalue.pop();
		object['GEC06'] = tempvalue;
		let gec7 = /CSC\s309/g;
		tempvalue = text.match(gec7);
		tempvalue.pop();
		tempvalue.pop();
		object['GEC07'] = tempvalue;
		object['GEC08'] = tempvalue;
		let gec9 = /CSC\s424\s/g;
		tempvalue = text.match(gec9);
		tempvalue.pop();
		object['GEC09'] = tempvalue;
	 	console.log(object);

		regex2 = /[A-Z]{3}\s\d{3}\/?L?\s-(\s\w+\s\w+\s\w+\s\w+\s\w+\s\w+|\s\w+\s\w+\s\w+\s\w+\s\w+|\s\w+\s\w+\s\w+\s\w+|\s\w+\s\w+\s\w+|\s\w+\s\w+)/gi;
		regex6 = /(<([^>]+)>)|AND/gi
		text = text.replace(regex6, "");
		regex7 = /;|#&|&#/gi
		text = text.replace(regex7, " ")
		regex8 = /\d{1}\shr\/?s?/gi;
		testResult = text.match(regex8);
	//	console.log(testResult);
		result = text.match(regex2);
		let tempresult = result;
	//	console.log(tempresult);
		let values = {};
		let arrayObj = {};
		let keys = {};
		for (key in result)
		{
			values = result[key].replace(/[A-Z]{3}\s\d{3}\/?L?\s-\s/, "");
			keys = result[key].replace(/\s-(\s\w+\s\w+\s\w+\s\w+\s\w+\s\w+\s\w+|\s\w+\s\w+\s\w+\s\w+\s\w+\s\w+|\s\w+\s\w+\s\w+\s\w+\s\w+|\s\w+\s\w+\s\w+\s\w+|\s\w+\s\w+\s\w+|\s\w+\s\w+)/, "");
			arrayObj[keys] = [values, testResult[key]];
		}
		console.log(arrayObj) //prints out entire key: value
	//	console.log(Object.keys(arrayObj)); //prints out keys
	//	console.log(Object.values(arrayObj)); //prints out values
	/*for (key in object)
	{
		for (keys in object[key])
		{
			//console.log(object[key][keys]); //prints out the courses individually
		}
			//console.log(object[key]); //prints out the courses in each GEC
	}*/
	})
});
	//introduced a promise instead, makes a future value that will be available in the future, or an error has occurred

	
	